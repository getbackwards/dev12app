# These are the project files for the project and section they are featured in

# Install the dependencies

npm install

# Start the application

npm start

